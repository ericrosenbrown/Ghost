import logging

from random import randint

from flask import Flask, render_template

from flask_ask import Ask, statement, question, session


app = Flask(__name__)

ask = Ask(app, "/")

logging.getLogger("flask_ask").setLevel(logging.DEBUG)


@ask.launch

def new_game():

    welcome_msg = render_template('welcome')

    return question(welcome_msg)


@ask.intent("YesIntent")

def next_round():

    numbers = [randint(0, 9) for _ in range(3)]

    round_msg = render_template('round', numbers=numbers)

    session.attributes['numbers'] = numbers[::-1]  # reverse

    return question(round_msg)

@ask.intent("InstructionsIntent")
def instructions_intent():
    instructions_msg = render_template('instructions')
    return question(instructions_msg)

@ask.intent("StartRoundIntent")
def start_round():
    session.attributes['word_fragment'] = 'd'
    print "the starting word_fragment is", session.attributes['word_fragment']
    return play_round()

def play_round():
    round_msg = render_template('get_next_letter',word_fragment = ['g','a'])
    return question(round_msg).reprompt("I didn't get that. What is your letter?")

@ask.intent("GiveLetterIntent", convert={'letter': str})
def answer_intent(letter):
    word_fragment = session.attributes['word_fragment']
    #TODO Add letter to word fragment, save in session, call function for saying round
    print word_fragment, letter

    return play_round()

@ask.intent('AMAZON.CancelIntent')
def exit_skill():
    return statement('')


if __name__ == '__main__':

    app.run(debug=True)
